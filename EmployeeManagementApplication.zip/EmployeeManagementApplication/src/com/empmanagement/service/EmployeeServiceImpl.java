package com.empmanagement.service;

import java.util.Map;

import com.empmanagement.dao.EmployeeDaoImpl;
import com.empmanagement.model.Employee;

public class EmployeeServiceImpl implements IEmployeeService{

		EmployeeDaoImpl empDao=new EmployeeDaoImpl();
	@Override
	public int addEmployee(Employee employee) {
		
		return empDao.addEmployee(employee);
	}

	@Override
	public Employee updateEmployee(Employee employee) {
		
		return empDao.updateEmployee(employee);
	}

	@Override
	public void deleteEmployee(int employeeId) {
		
		empDao.deleteEmployee(employeeId);
	}

	@Override
	public Employee getEmployee(int employeeId) {
	
		return empDao.getEmployee(employeeId);
	}

	@Override
	public Map<Integer, Employee> getAllEmployee() {
		
		return empDao.getAllEmployee();
		
	}

}
