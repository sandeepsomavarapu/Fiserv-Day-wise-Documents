package com.empmanagement.dao;

import java.util.Map;

import com.empmanagement.model.Employee;

public interface IEmployeeDao {
	int addEmployee(Employee employee);

	Employee updateEmployee(Employee employee);

	void deleteEmployee(int employeeId);

	Employee getEmployee(int employeeId);

	Map<Integer,Employee> getAllEmployee();
}
